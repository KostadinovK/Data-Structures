﻿using System;
using System.Collections.Generic;
using System.Linq;
using Wintellect.PowerCollections;

public class FirstLastList<T> : IFirstLastList<T> where T : IComparable<T>
{
    private LinkedList<T> byInsertion;
    private OrderedBag<T> byAscending;
    private OrderedBag<T> byDescending;

    public FirstLastList()
    {
        byInsertion = new LinkedList<T>();
        byAscending = new OrderedBag<T>((x,y) => x.CompareTo(y));
        byDescending = new OrderedBag<T>((x,y) => y.CompareTo(x));
    }

    public int Count
    {
        get
        {
            return byInsertion.Count;
        }
    }

    public void Add(T element)
    {
        byInsertion.AddLast(element);
        byAscending.Add(element);
        byDescending.Add(element);
    }

    public void Clear()
    {
        byInsertion.Clear();
        byAscending.Clear();
        byDescending.Clear();
    }

    public IEnumerable<T> First(int count)
    {
        if (count > byInsertion.Count)
        {
            throw new ArgumentOutOfRangeException();
        }

        int currentIteration = 0;
        LinkedListNode<T> current = byInsertion.First;

        while (currentIteration < count)
        {
            yield return current.Value;
            current = current.Next;
            currentIteration++;
        }
    }

    public IEnumerable<T> Last(int count)
    {
        if (count > byInsertion.Count)
        {
            throw new ArgumentOutOfRangeException();
        }

        int currentIteration = 0;
        LinkedListNode<T> current = byInsertion.Last;

        while (currentIteration < count)
        {
            yield return current.Value;
            current = current.Previous;
            currentIteration++;
        }
    }

    public IEnumerable<T> Max(int count)
    {
        if (count > byInsertion.Count)
        {
            throw new ArgumentOutOfRangeException();
        }

        return byDescending.Take(count);

    }

    public IEnumerable<T> Min(int count)
    {
        if (count > byInsertion.Count)
        {
            throw new ArgumentOutOfRangeException();
        }

        return byAscending.Take(count);
    }

    public int RemoveAll(T element)
    {
        if (!byAscending.Contains(element))
        {
            return 0;
        }

        int removedElements = byAscending.RemoveAllCopies(element);
        byDescending.RemoveAllCopies(element);

        LinkedListNode<T> node = new LinkedListNode<T>(element);

        int removedFromList = 0;
        while (removedFromList < removedElements)
        {
            byInsertion.Remove(node.Value);
            removedFromList++;
        }

        return removedElements;
    }
}
